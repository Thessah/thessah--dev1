// This file forces all /store routes to be dynamic
export const dynamic = 'force-dynamic'
export const dynamicParams = true
export const revalidate = 0
