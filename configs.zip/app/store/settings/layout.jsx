"use client";

export default function StoreSettingsLayout({ children }) {
  return (
    <>{children}</>
  );
}
