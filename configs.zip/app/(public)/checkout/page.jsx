import CheckoutPageUI from "./CheckoutPageUI";

export default function CheckoutPage() {
  return <CheckoutPageUI />;
}
