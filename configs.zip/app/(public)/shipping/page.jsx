export default function Shipping() {
  return (
    <div className="max-w-2xl mx-auto py-12 px-4">
      <h1 className="text-2xl font-bold mb-4">Shipping</h1>
      <p>This is the Shipping policy page. Please update with your actual shipping information.</p>
    </div>
  );
}
