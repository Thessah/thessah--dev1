'use client'
import dynamic from 'next/dynamic'



export default function PricingPage() {
    return (
        <div className='mx-auto max-w-[700px] my-28'>
            <div className="flex justify-center items-center min-h-[400px] text-gray-500">
                Pricing table coming soon...
            </div>
        </div>
    )
}