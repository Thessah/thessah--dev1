"use client";
import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import axios from "axios";
import { toast } from "react-hot-toast";

function TrackOrderPageInner() {
  const [email, setEmail] = useState('')
  const [orderNumber, setOrderNumber] = useState('')
  const searchParams = useSearchParams();
  const [loading, setLoading] = useState(false)
  const [order, setOrder] = useState(null)
  const [notFound, setNotFound] = useState(false)

  useEffect(() => {
    const orderId = searchParams.get("orderId");
    if (orderId) {
      setOrderNumber(orderId);
    }
  }, [searchParams]);

  const handleTrack = async (e) => {
    e.preventDefault()
    if (!email.trim() || !orderNumber.trim()) {
      toast.error('Please enter Email and Order Number')
      return
    }

    setLoading(true)
    setNotFound(false)
    setOrder(null)

    try {
      const params = new URLSearchParams()
      params.append('email', email.trim())
      params.append('awb', orderNumber.trim())
      
      const res = await axios.get(`/api/track-order?${params.toString()}`)
      if (res.data.success && res.data.order) {
        setOrder(res.data.order)
      } else {
        setNotFound(true)
        toast.error('Order not found')
      }
    } catch (error) {
      console.error('Track order error:', error)
      setNotFound(true)
      toast.error(error.response?.data?.message || 'Order not found')
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status) => {
    switch (status?.toUpperCase()) {
      case 'DELIVERED':
        return 'bg-green-100 text-green-700';
      case 'OUT_FOR_DELIVERY':
        return 'bg-teal-100 text-teal-700';
      case 'SHIPPED':
        return 'bg-blue-100 text-blue-700';
      case 'WAREHOUSE_RECEIVED':
        return 'bg-indigo-100 text-indigo-700';
      case 'PICKED_UP':
        return 'bg-purple-100 text-purple-700';
      case 'PICKUP_REQUESTED':
        return 'bg-yellow-100 text-yellow-700';
      case 'WAITING_FOR_PICKUP':
        return 'bg-yellow-50 text-yellow-700';
      case 'CONFIRMED':
        return 'bg-orange-100 text-orange-700';
      case 'PROCESSING':
        return 'bg-yellow-100 text-yellow-700';
      case 'RETURN_REQUESTED':
        return 'bg-pink-100 text-pink-700';
      case 'RETURNED':
        return 'bg-pink-200 text-pink-800';
      case 'CANCELLED':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-slate-100 text-slate-700';
    }
  }

  const getStatusSteps = (status) => {
    // Expanded status steps for more granular tracking
    const steps = [
      'ORDER_PLACED',
      'CONFIRMED',
      'PROCESSING',
      'PICKUP_REQUESTED',
      'WAITING_FOR_PICKUP',
      'PICKED_UP',
      'WAREHOUSE_RECEIVED',
      'SHIPPED',
      'OUT_FOR_DELIVERY',
      'DELIVERED',
      'RETURN_REQUESTED',
      'RETURNED',
      'CANCELLED'
    ];
    const currentIndex = steps.indexOf(status?.toUpperCase());
    return steps.map((step, idx) => ({
      name: step.replace(/_/g, ' '),
      completed: idx <= currentIndex,
      active: idx === currentIndex
    }));
  }

  return (
    <>
      {/* <Navbar /> removed, now global via ClientLayout */}
      <div className="min-h-screen bg-slate-50 py-12">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-slate-800 mb-2">Track Your Order</h1>
            <p className="text-slate-600">Please enter your email address and order number to view your order status.</p>
          </div>

          {/* Search Form */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-8">
            <form onSubmit={handleTrack} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Email Address</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Order Number</label>
                <input
                  type="text"
                  value={orderNumber}
                  onChange={(e) => setOrderNumber(e.target.value)}
                  placeholder="AWB / Order ID / Order No"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-slate-800 text-white py-3 rounded-lg hover:bg-slate-700 transition disabled:opacity-50 disabled:cursor-not-allowed font-medium"
              >
                {loading ? 'Tracking...' : 'TRACK ORDER'}
              </button>
            </form>
          </div>

          {/* Order Not Found */}
          {notFound && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-center">
              <svg className="w-16 h-16 text-red-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
              <h3 className="text-lg font-semibold text-slate-800 mb-2">Order Not Found</h3>
              <p className="text-slate-600">Please check your Phone Number or AWB Number and try again.</p>
            </div>
          )}

          {/* Order Details */}
          {order && (
            <div className="space-y-6">
              {/* Order Status */}
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-xl font-semibold text-slate-800">
                      Order ID: {(order._id || order.id || '')}
                    </h2>
                    <p className="text-sm text-slate-600 mt-1">Placed on {new Date(order.createdAt).toLocaleDateString()}</p>
                  </div>
                  <span className={`px-4 py-2 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
                    {order.status || 'ORDER_PLACED'}
                  </span>
                </div>

                {/* Progress Tracker */}
                <div className="relative">
                  <div className="flex justify-between mb-2">
                    {getStatusSteps(order.status).map((step, idx) => (
                      <div key={idx} className="flex flex-col items-center flex-1">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${
                          step.completed ? 'bg-blue-500 border-blue-500' : 'bg-white border-slate-300'
                        }`}>
                          {step.completed ? (
                            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          ) : (
                            <span className="text-slate-400 text-sm">{idx + 1}</span>
                          )}
                        </div>
                        <p className={`text-xs mt-2 text-center ${step.completed ? 'text-slate-800 font-medium' : 'text-slate-500'}`}>
                          {step.name}
                        </p>
                      </div>
                    ))}
                  </div>
                  <div className="absolute top-5 left-0 right-0 h-0.5 bg-slate-200 -z-10" style={{marginLeft: '5%', marginRight: '5%'}}></div>
                </div>
              </div>

              {/* Tracking Info */}
              {(order.trackingId || order.trackingUrl || order.courier) && (
                <>
                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                      <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      Tracking Information
                    </h3>
                    <div className="space-y-3">
                      {order.courier && (
                        <div className="flex items-center gap-3">
                          <span className="text-slate-600 font-medium min-w-[120px]">Courier:</span>
                          <span className="text-slate-800">{order.courier}</span>
                        </div>
                      )}
                      {order.trackingId && (
                        <div className="flex items-center gap-3">
                          <span className="text-slate-600 font-medium min-w-[120px]">Tracking ID:</span>
                          <span className="font-mono text-slate-800 bg-white px-3 py-1 rounded">{order.trackingId}</span>
                        </div>
                      )}
                      {order.trackingUrl && (
                        <div className="flex items-center gap-3">
                          <span className="text-slate-600 font-medium min-w-[120px]">Track Shipment:</span>
                          <a 
                            href={order.trackingUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline flex items-center gap-1 font-medium"
                          >
                            Click here to track on courier website
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                            </svg>
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                  {/* More tracking details/help */}
                  <div className="bg-slate-100 border border-slate-200 rounded-xl p-4 mt-4 text-sm text-slate-700">
                    <p>
                      <strong>How tracking works:</strong> Once your order is shipped, you will receive a tracking ID and courier details. Use the tracking link above to see real-time shipment status on the courier's website. If tracking is not yet available, please check back later or contact our support team for assistance.
                    </p>
                  </div>
                </>
              )}

              {/* Order Items */}
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <h3 className="text-lg font-semibold text-slate-800 mb-4">Order Items</h3>
                <div className="space-y-4">
                  {(order.orderItems || []).map((item, idx) => {
                    const product = item.productId || item.product || {}
                    return (
                      <div key={idx} className="flex items-start gap-4 pb-4 border-b border-slate-100 last:border-0">
                        <div className="w-20 h-20 bg-slate-100 rounded-lg overflow-hidden flex-shrink-0">
                          {product.images?.[0] ? (
                            <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-slate-400 text-xs">No image</div>
                          )}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-slate-800">{product.name || 'Product'}</h4>
                          <p className="text-sm text-slate-600 mt-1">Quantity: {item.quantity}</p>
                          <p className="text-sm text-slate-600">Price: AED {(item.price || 0).toFixed(2)}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-slate-800">AED {((item.price || 0) * (item.quantity || 0)).toFixed(2)}</p>
                        </div>
                      </div>
                    )
                  })}
                </div>
                <div className="mt-4 pt-4 border-t border-slate-200">
                  <div className="flex justify-between text-slate-800 font-semibold">
                    <span>Total:</span>
                    <span>₹{(order.total || 0).toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Shipping Address */}
              {order.shippingAddress && (
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Shipping Address</h3>
                  <div className="text-slate-700 space-y-1">
                    <p className="font-medium">{order.shippingAddress.name}</p>
                    <p>{order.shippingAddress.street}</p>
                    <p>{order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zip}</p>
                    <p>{order.shippingAddress.country}</p>
                    {order.shippingAddress.phone && <p className="mt-2">Phone: {order.shippingAddress.phone}</p>}
                  </div>
                </div>
              )}
              {/* Info about login for order details/history */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mt-6 text-center">
                <p className="text-blue-700 font-medium">For full order details and history, please <a href="/login" className="underline text-blue-800">login</a> to your account. You will also receive an email with order information after every update.</p>
              </div>
            </div>
          )}
        </div>
      </div>
      {/* <Footer /> removed, now global via ClientLayout */}
    </>
  );
}

export default function TrackOrderPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><span>Loading...</span></div>}>
      <TrackOrderPageInner />
    </Suspense>
  );
}
