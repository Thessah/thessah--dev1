// This component is now redundant and has been removed after merging India checkout into the main OrderSummary.
// File intentionally left blank.
