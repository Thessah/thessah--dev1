-- CreateIndex
CREATE INDEX "Product_category_idx" ON "Product"("category");
