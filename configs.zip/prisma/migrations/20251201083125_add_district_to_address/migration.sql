-- AlterTable
ALTER TABLE "Address" ADD COLUMN     "district" TEXT;
